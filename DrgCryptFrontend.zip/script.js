function process() {
  const mode = document.getElementById("modeSelect").value;
  const input = document.getElementById("inputText").value;
  const password = document.getElementById("password").value;
  const deviceHash = document.getElementById("deviceHash").value;
  const captchaToken = grecaptcha.getResponse();

  if (!captchaToken) {
    alert("Lütfen reCAPTCHA doğrulamasını yapın.");
    return;
  }

  if (!input || !password || !deviceHash) {
    alert("Tüm alanları doldurun.");
    return;
  }

  const payload = {
    text: input,
    password: password,
    deviceHash: deviceHash,
    captcha: captchaToken
  };

  const url = mode === "encrypt" ? "/api/sedcrypt/encrypt" : "/api/sedcrypt/decrypt";

  fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
    .then(res => res.json())
    .then(data => {
      document.getElementById("outputText").value = data.result || "Bir hata oluştu.";
    })
    .catch(() => {
      alert("İşlem sırasında bir hata oluştu.");
    });
}

function copyOutput() {
  const output = document.getElementById("outputText");
  output.select();
  document.execCommand("copy");
  alert("Sonuç kopyalandı!");
}

function checkPasswordStrength() {
  const pass = document.getElementById("password").value;
  const strengthText = document.getElementById("strengthText");

  if (pass.length < 6) {
    strengthText.innerText = "Çok zayıf";
    strengthText.style.color = "red";
  } else if (pass.match(/[A-Z]/) && pass.match(/[0-9]/) && pass.match(/[\W_]/)) {
    strengthText.innerText = "Güçlü";
    strengthText.style.color = "green";
  } else {
    strengthText.innerText = "Orta";
    strengthText.style.color = "orange";
  }
}

async function showHashPreview() {
  const input = document.getElementById("inputText").value;
  const msgBuffer = new TextEncoder().encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  document.getElementById("hashPreview").innerText = hashHex.substring(0, 20) + "...";
}

function toggleTheme() {
  document.body.classList.toggle("dark-mode");
}

function generateStrongKey() {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+{}[]<>?/";
  let key = "";
  for (let i = 0; i < 24; i++) {
    key += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  document.getElementById("password").value = key;
  checkPasswordStrength();
}