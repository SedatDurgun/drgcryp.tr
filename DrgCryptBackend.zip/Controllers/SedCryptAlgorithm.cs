using System.Text;
using System.Security.Cryptography;

namespace SedCrypt.API.Controllers
{
    public static class SedCryptAlgorithm
    {
        public static string Encrypt(string input, string password)
        {
            // PBKDF2 kullanarak anahtar türetme
            var salt = Encoding.UTF8.GetBytes("SedCrypt-Salt");
            var key = new Rfc2898DeriveBytes(password, salt, 10000, HashAlgorithmName.SHA256).GetBytes(32);

            // AES ile şifreleme (örnek)
            using var aes = Aes.Create();
            aes.Key = key;
            aes.GenerateIV();

            using var encryptor = aes.CreateEncryptor();
            var inputBytes = Encoding.UTF8.GetBytes(input);
            var encryptedBytes = encryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);

            // IV + Encrypted formatında geri döndür
            var combined = new byte[aes.IV.Length + encryptedBytes.Length];
            Buffer.BlockCopy(aes.IV, 0, combined, 0, aes.IV.Length);
            Buffer.BlockCopy(encryptedBytes, 0, combined, aes.IV.Length, encryptedBytes.Length);
            return Convert.ToBase64String(combined);
        }

        public static string Decrypt(string cipherText, string password)
        {
            try
            {
                var fullCipher = Convert.FromBase64String(cipherText);
                var salt = Encoding.UTF8.GetBytes("SedCrypt-Salt");
                var key = new Rfc2898DeriveBytes(password, salt, 10000, HashAlgorithmName.SHA256).GetBytes(32);

                using var aes = Aes.Create();
                aes.Key = key;

                byte[] iv = new byte[16];
                byte[] cipher = new byte[fullCipher.Length - 16];

                Buffer.BlockCopy(fullCipher, 0, iv, 0, iv.Length);
                Buffer.BlockCopy(fullCipher, iv.Length, cipher, 0, cipher.Length);
                aes.IV = iv;

                using var decryptor = aes.CreateDecryptor();
                var decryptedBytes = decryptor.TransformFinalBlock(cipher, 0, cipher.Length);
                return Encoding.UTF8.GetString(decryptedBytes);
            }
            catch
            {
                return "Çözme Başarısız";
            }
        }
    }
}