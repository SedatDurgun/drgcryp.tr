using Microsoft.AspNetCore.Mvc;

namespace SedCrypt.API.Controllers
{
    [ApiController]
    [Route("api/sedcrypt")]
    public class SedCryptController : ControllerBase
    {
        [HttpPost("encrypt")]
        public IActionResult Encrypt([FromBody] EncryptionRequest request)
        {
            if (!ModelState.IsValid) return BadRequest("Geçersiz veri");
            var encrypted = SedCryptAlgorithm.Encrypt(request.Text, request.Password);
            return Ok(new { result = encrypted });
        }

        [HttpPost("decrypt")]
        public IActionResult Decrypt([FromBody] EncryptionRequest request)
        {
            if (!ModelState.IsValid) return BadRequest("Geçersiz veri");
            var decrypted = SedCryptAlgorithm.Decrypt(request.Text, request.Password);
            return Ok(new { result = decrypted });
        }
    }

    public class EncryptionRequest
    {
        public string Text { get; set; }
        public string Password { get; set; }
        public string DeviceHash { get; set; }
        public string Captcha { get; set; }
    }
}